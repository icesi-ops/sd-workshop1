INSERT INTO invoice(id_invoice, amount, state) VALUES(1, 1000, 0);
INSERT INTO invoice(id_invoice, amount, state) VALUES(2, 5000, 1);
INSERT INTO invoice(id_invoice, amount, state) VALUES(3, 300, 0);
INSERT INTO invoice(id_invoice, amount, state) VALUES(4, 600, 0);
INSERT INTO invoice(id_invoice, amount, state) VALUES(5, 400, 0);