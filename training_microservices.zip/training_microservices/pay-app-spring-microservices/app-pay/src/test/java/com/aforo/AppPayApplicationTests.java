package com.aforo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppPayApplicationTests {

    @Test
    void contextLoads() {
    }

}
